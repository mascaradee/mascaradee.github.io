---
layout: post
date: 2017-06-09 14:28:00 +0900
title: '[Java] error와 exception의 차이'
categories:
  - java
tags:
  - java
  - error
  - exception
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://stackoverflow.com/questions/912334/differences-between-exception-and-error](https://stackoverflow.com/questions/912334/differences-between-exception-and-error)
- [https://speakerdeck.com/gousiosg/exception-handling-bug-hazards-on-android?slide=8](https://speakerdeck.com/gousiosg/exception-handling-bug-hazards-on-android?slide=8)

![](/images/error-differ-exception-1.png)

ㅇㅗㅏ우!
