---
layout: post
date: 2019-05-15 09:48:00 +0900
title: '[jQuery] .map(), jQuery.map()'
categories:
  - jquery
tags:
  - javascript
  - jquery
  - map
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [http://api.jquery.com/map/](http://api.jquery.com/map/)
- [http://api.jquery.com/jQuery.map/](http://api.jquery.com/jQuery.map/)

## .map()

광역 선택 후 특정 값만 배열로 뽑아낼 때 사용함.

## jQuery.map()

얜 뭐죠.
