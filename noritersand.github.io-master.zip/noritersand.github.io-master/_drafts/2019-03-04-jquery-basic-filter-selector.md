---
layout: post
date: 2019-03-04 11:05:00 +0900
title: '[jQuery] basic filter selector'
categories:
  - jquery
tags:
  - javascript
  - jquery
  - selector
  - basic-filter
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://api.jquery.com/category/selectors/basic-filter-selectors/](https://api.jquery.com/category/selectors/basic-filter-selectors/)


## :animated Selector

## :eq() Selector

## :even Selector

## :first Selector

## :focus Selector

## :gt() Selector

## :header Selector

## :lang() Selector

## :last Selector

## :lt() Selector

## :not() Selector

## :odd Selector

## :root Selector

## :target Selector
