---
layout: post
date: 2016-07-27 12:04:00 +0900
title: '[JavaScript] Number'
categories:
  - javascript
tags:
  - ecmascript
  - javascript
  - number
  - standard-built-in-objects
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number)

Standard built-in Objects: Number
