---
layout: post
date: 2017-02-03 13:44:00 +0900
title: '[JavaScript] substring과 slice'
categories:
  - javascript
tags:
  - ecmascript
  - javascript
  - substring
  - slice
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String)
- [https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/substring](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/substring)
- [https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/slice](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/slice)
- [http://stackoverflow.com/questions/2243824/what-is-the-difference-between-string-slice-and-string-substring](http://stackoverflow.com/questions/2243824/what-is-the-difference-between-string-slice-and-string-substring)


substring()



slice()



무엇이 다른가?

slice()는 endIndex가 음수(negative)일 때 끝에서 자른다.
