---
layout: post
date: 2019-09-23 18:27:00 +0900
title: '[영어넘모어려워] 전치사 preposition'
categories:
  - english
tags:
  - english
  - noteasy
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://heiswed.tistory.com](https://heiswed.tistory.com)

![](/images/prepositions.jpg)

이미지 출처: [https://heiswed.tistory.com/entry/해외-여행을-위한-영어-공부-문법-정리-7편-전치사](https://heiswed.tistory.com/entry/해외-여행을-위한-영어-공부-문법-정리-7편-전치사)

## 전치사

### to

- adverb(부사, here, there) 앞에는 to가 필요 없다. (there 이미 to의 의미를 포함한다. 거기로, 거기에...)
- 동사원형일 때 to가 필요하지만 몇몇 동사는 과거분사형일 때 to를 필요로 하지 않는다.
