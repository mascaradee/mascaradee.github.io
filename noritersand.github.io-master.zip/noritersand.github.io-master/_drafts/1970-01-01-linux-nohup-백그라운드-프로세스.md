---
layout: post
date: 1970-01-01 00:00:00 +0900
title: '[Linux] nohup 백그라운드 프로세스 생성'
categories:
  - linux
tags:
  - os
  - linux
  - nohup
---

#### 참고한 문서

- [http://changpd.blogspot.kr/2013/04/linux-nohup-xxxsh.html](http://changpd.blogspot.kr/2013/04/linux-nohup-xxxsh.html)

``` bash
nohup java -jar example.jar &
```

`&` 만 쳐도 되는모양?
