---
layout: post
date: 2016-07-27 12:01:00 +0900
title: '[JavaScript] String'
categories:
  - javascript
tags:
  - javascript
  - ecmascript
  - string
  - standard-built-in-objects
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String)

Standard built-in Objects: String
