---
layout: post
date: 2017-02-03 00:00:10 +0900
title: '[JavaScript] WCAG(웹 콘텐츠 접근성 지침) 2.0을 위한 클라이언트측 스크립팅 기법'
categories:
  - javascript
tags:
  - ecmascript
  - javascript
  - wcag
  - 웹접근성
---

- [원문](https://www.w3.org/TR/WCAG20-TECHS/client-side-script.html)
- [번역](http://www.wah.or.kr/TR/WCAG20-TECHS/client-side-script.HTML)
