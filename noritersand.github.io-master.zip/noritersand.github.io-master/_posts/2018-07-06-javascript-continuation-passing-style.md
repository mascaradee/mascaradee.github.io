---
layout: post
date: 2018-07-06 17:52:58 +0900
title: '[JavaScript] continuation-passing style'
categories:
  - javascript
tags:
  - ecmascript
  - javascript
  - cps
  - continuation-passing-style
---

- 원문: [http://matt.might.net/articles/by-example-continuation-passing-style/](http://matt.might.net/articles/by-example-continuation-passing-style/)
- 한글번역: [http://dogfeet.github.io/articles/2012/by-example-continuation-passing-style-in-javascript.html](http://dogfeet.github.io/articles/2012/by-example-continuation-passing-style-in-javascript.html)
