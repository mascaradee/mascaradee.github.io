---
layout: post
date: 2019-05-16 10:12:00 +0900
title: '[Windows] NotMyFault'
categories:
  - windows
tags:
  - os
  - crash
  - hang
  - leaf
  - dump
---

* Kramdown table of contents
{:toc .toc}

#### 참고한 문서

- [https://docs.microsoft.com/en-us/sysinternals/](https://docs.microsoft.com/en-us/sysinternals/)
- [https://docs.microsoft.com/en-us/sysinternals/downloads/notmyfault](https://docs.microsoft.com/en-us/sysinternals/downloads/notmyfault)

crash(시스템 다운), hang(프리징), 메모리 누수를 강제로 일으킬 수 있는 도구. 최근에 배포된 줄 알았더니 겁나 오래된 툴이다.

시스템 다운을 분석해주는 유틸리티인 줄 알고 아무 버튼이나 눌러봤다가 깜짝 놀랬다.
