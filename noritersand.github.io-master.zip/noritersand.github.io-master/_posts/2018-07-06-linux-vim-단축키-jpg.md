---
layout: post
date: 2018-07-06 15:57:35 +0900
title: '[Linux] Vim 단축키.jpg'
categories:
  - linux
tags:
  - os
  - linux
  - vim
---

위키: [http://www.joinc.co.kr/modules/moniwiki/wiki.php/Site/Vim/Documents/UsedVim](http://www.joinc.co.kr/modules/moniwiki/wiki.php/Site/Vim/Documents/UsedVim)

![](/images/vim-hotkey-1.png)
![](/images/vim-hotkey-2.jpg)
