---
layout: post
date: 2018-04-18 17:28:49 +0900
title: '[Eclipse] easy console grepper 권장 설정'
categories:
  - eclipse
tags:
  - devtool
  - eclipse
  - easy-console-grepper
---

![](/images/easy-console-grepper-1.png)
